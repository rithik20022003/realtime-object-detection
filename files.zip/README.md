# Life Insurance Management — Modules 6 & 7

Drop-in **Claim Management** (Module 6) and **Reports & Administration** (Module 7) for an existing Life Insurance Management application.

**Stack:** Java 17 · Spring Boot 3.2 · Spring Data JPA · SQLite 3 · Angular 17+ (standalone components, reactive forms).

This is **integration-ready feature code**, not a standalone runnable app. It assumes your project already has: a Spring Boot app, JWT/security with roles `CUSTOMER` / `AGENT` / `ADMIN`, and existing `customer`, `policy`, `app_user` (and a premium) tables/entities. Everything here references those by **ID** to stay loosely coupled, so you won't get entity-clash on import.

> Every place you may need to adjust to your schema/auth is flagged in-code with a comment. Search for `INTEGRATION POINT`, `adjust`, and `assumed`.

---

## What's included

### Module 6 — Claim Management
| US | Feature | Role | Screen / Endpoint |
|----|---------|------|-------------------|
| US-01 | Submit Claim | Customer | `POST /api/claims` · `claims/new` |
| US-02 | Upload Documents | Customer | `POST /api/claims/{id}/documents` · `claims/:id/documents` |
| US-03 | Verify Claim | Agent | `POST /api/claims/{id}/verify` + per-doc verify · `claims/:id/verify` |
| US-04 | Approve / Reject | Admin | `POST /api/claims/{id}/approve` \| `/reject` · `claims/:id/decision` |
| US-05 | Track Status | Customer | `GET /api/claims/{id}/tracking` · `claims/:id/track` |

### Module 7 — Reports & Administration (all Admin)
| US | Feature | Endpoint | Screen |
|----|---------|----------|--------|
| US-RA-01 | Customer Reports | `GET /api/reports/customers` | `reports/customers` |
| US-RA-02 | Policy Reports | `GET /api/reports/policies` | `reports/policies` |
| US-RA-03 | Premium Reports | `GET /api/reports/premiums` | `reports/premiums` |
| US-RA-04 | Claim Reports | `GET /api/reports/claims` | `reports/claims` |
| US-RA-05 | System Monitoring | `GET /api/admin/activity` | `admin/monitoring` |

---

## File tree

```
life-insurance-claim-reports/
├── database/
│   └── schema.sql                     # new tables for Module 6 (+ activity log)
├── backend/
│   └── src/main/
│       ├── java/com/insurance/
│       │   ├── claim/                 # entity, repository, dto, service, controller
│       │   ├── reports/               # dto, service (JdbcTemplate), controller
│       │   ├── admin/                 # system activity log (entity/repo/service/controller)
│       │   └── common/                # exception, security, storage, config
│       └── resources/
│           └── application-claim-reports.yml   # keys to merge into your config
└── frontend/
    ├── proxy.conf.json                # dev: maps /api -> http://localhost:8080
    └── src/app/
        ├── claim/                     # models, service, 5 standalone components
        ├── reports/                   # models, service, 5 standalone components
        └── claim-reports.routes.ts    # route table for all screens
```

---

## Backend integration (6 steps)

1. **Copy** `backend/src/main/java/com/insurance/**` into your source tree. If your base package isn't `com.insurance`, do a find-and-replace on the package declarations.
2. **Add the SQLite dependencies** to your `pom.xml` — the JDBC driver and the community Hibernate dialect (Spring Boot 3.2 ships Hibernate 6.4.x; match that version):
   ```xml
   <dependency>
     <groupId>org.xerial</groupId>
     <artifactId>sqlite-jdbc</artifactId>
     <version>3.45.3.0</version>
   </dependency>
   <dependency>
     <groupId>org.hibernate.orm</groupId>
     <artifactId>hibernate-community-dialects</artifactId>
     <version>6.4.4.Final</version>
   </dependency>
   ```
   (Gradle: `implementation 'org.xerial:sqlite-jdbc:3.45.3.0'` and `implementation 'org.hibernate.orm:hibernate-community-dialects:6.4.4.Final'`.)
3. **Create the schema** — run `database/schema.sql` against your SQLite DB file:
   ```bash
   sqlite3 life_insurance.db < database/schema.sql
   ```
   Or copy it to `src/main/resources/schema.sql` and set `spring.sql.init.mode: always` to have Spring Boot create it on startup. Adjust the FK references (`policy(id)`, `customer(id)`) if your table names differ — or drop the FK constraints and keep the plain ID columns.
4. **Merge** `application-claim-reports.yml` into your `application.yml` — it sets the SQLite datasource, the `SQLiteDialect`, multipart limits, and `claim.storage.*`. The JDBC URL turns on `foreign_keys`, `WAL`, and a `busy_timeout`. Set `claim.storage.base-dir` to an absolute path in production.
5. **Wire security** — the code reads the current user via `CurrentUserProvider`. The default `SecurityContextCurrentUserProvider` assumes the JWT subject is the numeric user ID and authorities are `ROLE_CUSTOMER` etc. If yours differ, provide your own `@Primary` bean implementing `CurrentUserProvider` (one small class). If your project already calls `@EnableMethodSecurity`, **delete** `common/config/MethodSecurityConfig.java` to avoid a duplicate.
6. **Reports column names** — `reports/service/ReportService.java` uses native SQL with placeholder column names (`customer.full_name`, `policy.plan_name`, `premium.payment_status`, …). Each is flagged; map them to your actual columns. The SQL is plain ANSI (no MySQL-specific functions), so it runs as-is on SQLite. The claim report uses the JPA repository and needs no changes.

### Roles
Every controller method is guarded with `@PreAuthorize` (`hasRole('CUSTOMER'|'AGENT'|'ADMIN')`). Customer endpoints additionally scope to the authenticated customer's own claims server-side, satisfying US-05 AC4 (and US-02 own-claim upload).

### Claim status workflow
```
SUBMITTED → DOCUMENTS_UPLOADED → UNDER_VERIFICATION
          → VERIFIED ─────────→ APPROVED
          → VERIFICATION_FAILED  REJECTED
```
Status, decision, and document-verification transitions are validated in `ClaimService` / `ClaimDocumentService`. Approve is only allowed from `VERIFIED`; reject requires a reason (US-04 AC2). Decision and status history rows are written on every transition (US-04 AC4), and important actions are recorded to the activity log (US-RA-05 AC2).

### Documents
Stored on the filesystem (`claim.storage.base-dir`) with metadata in `claim_document`. Content-type and size are validated against the configured allow-list (PDF/JPEG/PNG, 10 MB). To move to S3, swap the body of `FileStorageService` — the interface stays the same.

---

## Frontend integration (3 steps)

1. **Copy** `frontend/src/app/claim/` and `frontend/src/app/reports/` into your Angular app, plus `claim-reports.routes.ts`.
2. **Merge routes** — spread `claimReportsRoutes` into your root `Routes`, and attach your own `roleGuard` to the `canActivate` arrays (commented stubs show the intended role per route). Ensure `provideHttpClient()` is in your app config.
   ```ts
   import { claimReportsRoutes } from './app/claim-reports.routes';
   export const routes: Routes = [ ...existing, ...claimReportsRoutes ];
   ```
3. **Dev proxy** — add `proxy.conf.json` and run `ng serve --proxy-config proxy.conf.json` so `/api/**` reaches Spring Boot on `:8080`. In production, point the services' `base` at your API host (or keep `/api` behind a reverse proxy).

The components reference two of **your** existing endpoints with graceful fallbacks: `GET /api/policies/my` (policy picker on Submit Claim) — adjust if yours differs. No external UI library is used; styling is plain scoped CSS (navy/blue) so it won't fight your design system.

---

## Notes & assumptions
- Java/Spring versions and Lombok are assumptions; all swappable.
- **SQLite specifics:** IDs use `INTEGER PRIMARY KEY AUTOINCREMENT` and JPA `GenerationType.IDENTITY` (works via `SQLiteDialect`). Foreign keys are enforced only with `foreign_keys=ON` (set in the JDBC URL). SQLite has no `ON UPDATE CURRENT_TIMESTAMP`, so `claim.updated_at` is maintained by the JPA `@PreUpdate` hook, with a DB trigger in `schema.sql` as a backup. SQLite is single-writer; the config uses WAL mode + a busy-timeout + a small pool to stay stable — fine for dev and small/medium load. For high write concurrency, use a server DB instead.
- `app_user`, `customer`, `policy`, and a premium table are assumed to exist. The reports for customers/policies/premiums read those tables directly; only `claim*` and `system_activity_log` tables are created by `schema.sql`.
- No tests are included; add to your project's existing test setup as needed.
